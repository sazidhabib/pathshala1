<?php
$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "pathshala";

$connect = mysqli_connect($hostname, $username, $password, $databaseName);
?>