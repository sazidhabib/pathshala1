<?php

require 'db/dbcon.php';


//==================Student===================================>

if(isset($_POST['update_student']))
{
    $id = mysqli_real_escape_string($con, $_POST['id']);

    $password = mysqli_real_escape_string($con, $_POST['password']);

    if($password == NULL)
    {
        $res = [
            'status' => 422,
            'message' => 'All fields are mandatory'
        ];
        echo json_encode($res);
        return;
    }

    $query = "UPDATE user_std SET password='$password'
                WHERE id='$id'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $res = [
            'status' => 200,
            'message' => 'Password Updated Successfully'
        ];
        echo json_encode($res);
        return;
    }
    else
    {
        $res = [
            'status' => 500,
            'message' => 'Password Not Updated'
        ];
        echo json_encode($res);
        return;
    }
}


if(isset($_GET['id']))
{
    $id = mysqli_real_escape_string($con, $_GET['id']);

    $query = "SELECT * FROM user_std WHERE id='$id'";
    $query_run = mysqli_query($con, $query);

    if(mysqli_num_rows($query_run) == 1)
    {
        $user_std = mysqli_fetch_array($query_run);

        $res = [
            'status' => 200,
            'message' => 'User Fetch Successfully by id',
            'data' => $user_std
        ];
        echo json_encode($res);
        return;
    }
    else
    {
        $res = [
            'status' => 404,
            'message' => 'User Id Not Found'
        ];
        echo json_encode($res);
        return;
    }
}

//==================Supervisor===================================>

if(isset($_POST['update_Supervisor']))
{
    $supervisor_id = mysqli_real_escape_string($con, $_POST['supervisor_id']);

    $name = mysqli_real_escape_string($con, $_POST['name']);
    $qualification = mysqli_real_escape_string($con, $_POST['qualification']);
    $taking_course = mysqli_real_escape_string($con, $_POST['taking_course']);
    $salary = mysqli_real_escape_string($con, $_POST['salary']);

    if($name == NULL || $qualification == NULL || $taking_course == NULL || $salary == NULL)
    {
        $res = [
            'status' => 422,
            'message' => 'All fields are mandatory'
        ];
        echo json_encode($res);
        return;
    }

    $query = "UPDATE supervisor SET name='$name', qualification='$qualification' , taking_course='$taking_course', salary='$salary'
                WHERE id='$supervisor_id'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $res = [
            'status' => 200,
            'message' => 'Supervisor Updated Successfully'
        ];
        echo json_encode($res);
        return;
    }
    else
    {
        $res = [
            'status' => 500,
            'message' => 'Supervisor Not Updated'
        ];
        echo json_encode($res);
        return;
    }
}




//==================Staff===================================>

if(isset($_POST['update_staff']))
{
    $staff_id = mysqli_real_escape_string($con, $_POST['staff_id']);

    $name = mysqli_real_escape_string($con, $_POST['name']);
    $designation = mysqli_real_escape_string($con, $_POST['designation']);
    $salary = mysqli_real_escape_string($con, $_POST['salary']);

    if($name == NULL || $designation == NULL || $salary == NULL)
    {
        $res = [
            'status' => 422,
            'message' => 'All fields are mandatory'
        ];
        echo json_encode($res);
        return;
    }

    $query = "UPDATE staff SET name='$name', designation='$designation', salary = '$salary'
                WHERE id='$staff_id'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $res = [
            'status' => 200,
            'message' => 'Staff Updated Successfully'
        ];
        echo json_encode($res);
        return;
    }
    else
    {
        $res = [
            'status' => 500,
            'message' => 'Staff Not Updated'
        ];
        echo json_encode($res);
        return;
    }
}







?>