<?php 
session_start();
include '../../db/dbcon.php';

if (isset($_POST['user_name']) && isset($_POST['password'])) {
	
	$user_name = $_POST['user_name'];
	$password = $_POST['password'];
	echo($user_name);

	if (empty($user_name)) {
		header("Location: login.php?error=Username is required");
	}else if (empty($password)){
		header("Location: login.php?error=Password is required&user_name=$user_name");
	}else {
		$stmt = $conn->prepare("SELECT * FROM user_spv WHERE user_name=?");
		$stmt->execute([$user_name]);

		if ($stmt->rowCount() === 1) {
			$user = $stmt->fetch();

			$spv_user_name = $user['user_name'];
			//$std_password = $user['password'];

			if ($user_name === $spv_user_name) {
				$_SESSION['spv_user_name'] = $spv_user_name;
				//$_SESSION['std_password'] = $std_password;
				header("Location: index.php");
			}else {
				header("Location: login.php?error=Incorect User name & pasword&user_name=$user_name");
			}
		}else {
			header("Location: login.php?error=Incorect User name & password&user_name=$user_name");
		}
	}
}
