<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Welcome Pathshala</title>
	<link href="css/styles.css" rel="stylesheet" />
</head>
<body>
	<div id="mainContainer">
  <div class="">
  <div class="row align-items-center">
    <div class="col-lg-4 col-md-4 col-xs-8 d-none d-lg-block d-md-block">
      <div id="mainBgn"></div>
    </div>
    <div class="col-lg-5 col-md-6 col-xs-12">
      <div class="p- centerOnMobile" >
        <div class="formContainer">
          <h2 class="p- h4 text-center"><i class="fas fa-lock me-2"></i> Login With</h2>
            <div id="btnHolder">
				<a href="login.php" class="btn btn-lg btn-success mt-3 w-100">Admin</a>
            </div>
			<br />
			<div id="btnHolder">
				<a href="auth/student/login.php" class="btn btn-lg btn-primary mt-3 w-100">Student</a>
            </div>
			<br />
			<div id="btnHolder">
				<a href="auth/supervisor/login.php" class="btn btn-lg btn-primary mt-3 w-100">Supervisor</a>
            </div>
			<br />
				<div id="btnHolder">
			<a href="auth/staff/login.php" class="btn btn-lg btn-primary mt-3 w-100">Staff</a>
            </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  </div>
</body>
</html>